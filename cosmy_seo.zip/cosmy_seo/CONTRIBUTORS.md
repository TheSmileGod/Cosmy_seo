# Contributors

Core brand: COSMY Site (product owner)

Maintainers:
- Dmitry [@TheSmileGod] — WP REST API, post types, settings.
- Sergey  — product spec, review.

Contributors:
- Anna  — admin UI (React), i18n.
- Ivan  — build pipeline, QA.

Changelog credits:
- v1.0.0 — @Dmitry: REST routes /articles, nonce; @Anna: settings UI.
- v1.0.1 - @Dmitry: REST routes /tags
- v1.6.0 - Realise
- v1.6.1 - v1.7.0 - Hot Fixes and test update system
