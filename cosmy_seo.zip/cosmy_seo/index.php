<?php

/*
Plugin Name: COSMY SEO
Text Domain: cosmy-seo
Description: COSMY Site — SEO module via REST API.
Version: 1.9.5
Author: COSMY Site 
Author URI: https://cosmy.site
Update URI: https://github.com/TheSmileGod/Cosmy_seo
*/

include_once 'jt_theme.php';
include_once 'jt_admin.php';
include_once 'jt_api.php';
