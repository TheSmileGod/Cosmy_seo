<?php

/*
Plugin Name: COSMY SEO
Description: REST API для загрузки статей.
Version: 1.6.2
Author: CaMnO
Update URI: https://github.com/TheSmileGod/Cosmy_seo
*/

include_once 'jt_theme.php';
include_once 'jt_admin.php';
include_once 'jt_api.php';
