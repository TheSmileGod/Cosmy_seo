<?php

/*
Plugin Name: COSMY SEO
Description: COSMY Site — SEO module via REST API.
Version: 1.6.4
Author: COSMY Site 
Author URI: https://cosmy.site
Text Domain: cosmy-seo
Update URI: https://github.com/TheSmileGod/Cosmy_seo
*/

include_once 'jt_theme.php';
include_once 'jt_admin.php';
include_once 'jt_api.php';
