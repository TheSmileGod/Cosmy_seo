<?php

/*
Plugin Name: COSMY SEO
Description: REST API для загрузки статей.
Version: 1.2.0
Author: CaMnO
*/

include_once 'jt_theme.php';
include_once 'jt_admin.php';
include_once 'jt_api.php';

